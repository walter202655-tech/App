/**
 * Aura100 v4.1 - AI Conversation Partner
 *
 * What changed vs v4.0:
 *  - Uses POST /api/ai/talk (streamed, in-character, short replies) so the chat
 *    feels like a real conversation instead of a teacher reply with a feedback block.
 *  - Corrections come separately from POST /api/ai/talk/feedback and appear under
 *    the learner's own message, so they never interrupt the flow.
 *  - Sends up to 16 previous turns (was 8) and never sends error/notice bubbles.
 *  - Voice input (Web Speech API), optional auto-read of replies, session summary.
 *  - Speaking activity is recorded using the real feedback result (was always "correct").
 *  - All text is rendered with textContent (no innerHTML on user/model text).
 */

(function (global) {
  "use strict";

  const SCENARIOS_METADATA = {
    free: {
      id: "free",
      name: "Conversación Libre",
      icon: "🌐",
      desc: "Conversación cotidiana abierta sobre cualquier tema que elijas.",
      initialPrompt: "Hello! I'm your Aura100 conversation coach. What would you like to talk about today?",
      suggestedStarters: ["Let's talk about travel.", "Can we practice English for work?", "Tell me about a good movie."]
    },
    restaurant: {
      id: "restaurant",
      name: "Restaurante",
      icon: "🍽️",
      desc: "Práctica pidiendo bebidas, platos, términos de cocción y la cuenta.",
      initialPrompt: "Good evening! Welcome to The Golden Bistro. Can I start you off with something to drink?",
      suggestedStarters: ["Could I see the menu, please?", "I'd like a glass of sparkling water.", "What do you recommend?"]
    },
    hotel: {
      id: "hotel",
      name: "Hotel & Check-in",
      icon: "🏨",
      desc: "Check-in, servicios del hotel, horarios y resolución de peticiones.",
      initialPrompt: "Good afternoon! Welcome to the Grand Horizon Hotel. Do you have a reservation with us?",
      suggestedStarters: ["Yes, I have a reservation under my name.", "What time is breakfast served?", "Could I request a late checkout?"]
    },
    directions: {
      id: "directions",
      name: "Direcciones en la Ciudad",
      icon: "🗺️",
      desc: "Pedir y dar indicaciones para llegar a museos, estaciones y lugares turísticos.",
      initialPrompt: "Hello there! You seem to be looking for something. Can I help you find your way?",
      suggestedStarters: ["Excuse me, how do I get to the central train station?", "Is the science museum within walking distance?", "Which bus goes downtown?"]
    },
    job: {
      id: "job",
      name: "Entrevista Profesional",
      icon: "💼",
      desc: "Práctica de entrevista formal sobre fortalezas, logros, resolución de problemas y aspiraciones.",
      initialPrompt: "Welcome to our interview session today. Please take a seat. Could you start by introducing yourself and your background?",
      suggestedStarters: ["Thank you. I have experience in project coordination...", "My greatest strength is solving complex problems in teams.", "I'm very excited about this role because..."]
    },
    friends: {
      id: "friends",
      name: "Amigos y Pasatiempos",
      icon: "👥",
      desc: "Conversación informal conociendo a alguien nuevo, compartiendo hobbies y música.",
      initialPrompt: "Hey! I haven't seen you around here before. Are you new to the campus / neighborhood?",
      suggestedStarters: ["Yes, I just moved here recently!", "I love photography and playing guitar in my free time.", "Do you know any good cafes nearby?"]
    },
    academic_debate: {
      id: "academic_debate",
      name: "Debate Académico",
      icon: "🎓",
      desc: "Discusión fundamentada con argumentación, concesiones y lenguaje formal (B2-C2).",
      initialPrompt: "Welcome to our academic discussion. Today's topic considers whether artificial intelligence will reshape higher education. What is your position?",
      suggestedStarters: ["From my perspective, AI will serve as a cognitive amplifier...", "While there are clear benefits, we must acknowledge ethical concerns...", "I would argue that human mentorship remains irreplaceable."]
    },
    presentation: {
      id: "presentation",
      name: "Práctica de Presentaciones",
      icon: "📊",
      desc: "Apertura de presentaciones, transición entre diapositivas y respuestas a preguntas de la audiencia.",
      initialPrompt: "The floor is yours. Whenever you are ready, please deliver the opening remarks of your presentation.",
      suggestedStarters: ["Good morning everyone, today I'd like to present our findings on...", "Let me begin by outlining the three main pillars of our project.", "Thank you for your attention; I'd now be delighted to take any questions."]
    }
  };

  const MAX_API_HISTORY = 16;
  const MAX_API_CONTENT = 1200;

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  class AIConversationPartner {
    constructor(appInstance) {
      this.app = appInstance;
      this.scenario = "restaurant";
      this.level = "B1";
      this.history = []; // { role, content, timestamp, feedback?, streaming?, isError?, isNotice? }
      this.vocabularyDiscovered = [];
      this.mistakesIdentified = [];
      this.stats = { turns: 0, clean: 0, corrected: 0 };
      this.isLoading = false;
      this.isOnlineAI = false;
      this.autoSpeak = false;
      this.autoSend = true;
      this.isListening = false;
      this.recognition = null;
      this._micBtn = null;
      this._renderQueued = false;
      this._session = 0;
      this._abort = null;
    }

    async init() {
      if (global.Aura100AI && typeof global.Aura100AI.checkHealth === "function") {
        const health = await global.Aura100AI.checkHealth();
        this.isOnlineAI = Boolean(health && health.status === "ok" && health.aiConfigured);
      }
      this._mountControls();
      this.resetSession(false);
    }

    setScenario(scenarioId) {
      if (SCENARIOS_METADATA[scenarioId]) {
        this.scenario = scenarioId;
        this.resetSession(true);
      }
    }

    setLevel(levelCode) {
      if (["A1", "A2", "B1", "B2", "C1", "C2"].includes(levelCode)) {
        this.level = levelCode;
        this.resetSession(true);
      }
    }

    resetSession() {
      this._session += 1; // invalidates any in-flight reply/feedback from the old session
      if (this._abort) { this._abort.abort(); this._abort = null; }
      if (global.speechSynthesis) global.speechSynthesis.cancel();
      this._stopMic();

      this.isLoading = false;
      this.history = [];
      this.vocabularyDiscovered = [];
      this.mistakesIdentified = [];
      this.stats = { turns: 0, clean: 0, corrected: 0 };

      const meta = SCENARIOS_METADATA[this.scenario] || SCENARIOS_METADATA.free;
      this.history.push({ role: "assistant", content: meta.initialPrompt, timestamp: Date.now() });
      this.render();
    }

    /* -------------------------------------------------------------- *
     * Sending a message
     * -------------------------------------------------------------- */

    async sendMessage(userText) {
      const cleanText = (userText || "").trim();
      if (!cleanText || this.isLoading) return;
      if (global.speechSynthesis) global.speechSynthesis.cancel();

      const session = this._session;
      const apiHistory = this._buildApiHistory(); // built BEFORE adding the new message
      const lastPartner = [...apiHistory].reverse().find(m => m.role === "assistant");

      const userMsg = { role: "user", content: cleanText, timestamp: Date.now(), feedback: null };
      this.history.push(userMsg);
      this.isLoading = true;
      this.render();

      const useAI = this.isOnlineAI && global.Aura100AI && typeof global.Aura100AI.talkStream === "function";
      let botMsg = null;

      try {
        if (useAI) {
          this._requestFeedback(userMsg, lastPartner ? lastPartner.content : "", session);

          botMsg = { role: "assistant", content: "", timestamp: Date.now(), streaming: true };
          this.history.push(botMsg);
          this._abort = new AbortController();

          const reply = await global.Aura100AI.talkStream(
            { message: cleanText, level: this.level, scenario: this.scenario, history: apiHistory },
            partial => {
              if (session !== this._session) return;
              botMsg.content = partial;
              this._queueRender();
            },
            this._abort.signal
          );
          if (session !== this._session) return;
          botMsg.content = reply;
          botMsg.streaming = false;
        } else {
          botMsg = { role: "assistant", content: this._generateRuleBasedReply(cleanText), timestamp: Date.now() };
          this.history.push(botMsg);
        }

        if (this.app && typeof this.app.addXp === "function") this.app.addXp(10);
        if (this.autoSpeak && this.app && typeof this.app.speakText === "function") {
          this.app.speakText(botMsg.content, 1.0);
        }
      } catch (error) {
        if (session !== this._session) return;
        this._removeMessage(botMsg);
        this._handleError(error, cleanText);
      } finally {
        if (session === this._session) {
          this._abort = null;
          this.isLoading = false;
          this.render();
        }
      }
    }

    _buildApiHistory() {
      return this.history
        .filter(m => m.content && !m.isError && !m.isNotice && !m.streaming)
        .slice(-MAX_API_HISTORY)
        .map(m => ({ role: m.role, content: m.content.slice(0, MAX_API_CONTENT) }));
    }

    _removeMessage(msg) {
      if (!msg) return;
      const idx = this.history.indexOf(msg);
      if (idx >= 0) this.history.splice(idx, 1);
    }

    _handleError(error, cleanText) {
      console.warn("AI Chat error:", error && (error.code || error.message));
      const code = error && error.code;

      if (code === "AI_NOT_CONFIGURED" || (error && error.status === 503)) {
        this.isOnlineAI = false;
        this.history.push({
          role: "assistant",
          isNotice: true,
          content: "ℹ️ El servicio de IA en la nube no está configurado (falta la clave en .env). Cambio al modo de práctica guiada local.",
          timestamp: Date.now()
        });
        this.history.push({ role: "assistant", content: this._generateRuleBasedReply(cleanText), timestamp: Date.now() });
        return;
      }

      let message;
      if (code === "REQUEST_TIMEOUT") message = "⏱️ La respuesta tardó demasiado. Puedes intentarlo de nuevo.";
      else if (code === "CONTENT_REVIEW_REQUIRED" || code === "OUTPUT_BLOCKED") message = `⚠️ ${error.message}`;
      else message = `⚠️ ${error && error.message ? error.message : "Error de conexión. Inténtalo nuevamente."}`;

      this.history.push({ role: "assistant", content: message, isError: true, timestamp: Date.now() });
    }

    /* -------------------------------------------------------------- *
     * Feedback (parallel, attached to the learner's own message)
     * -------------------------------------------------------------- */

    _requestFeedback(userMsg, partnerMessage, session) {
      if (!global.Aura100AI || typeof global.Aura100AI.talkFeedback !== "function") return;
      global.Aura100AI.talkFeedback({
        message: userMsg.content,
        partnerMessage: (partnerMessage || "").slice(0, MAX_API_CONTENT),
        level: this.level
      })
        .then(feedback => {
          if (session !== this._session) return;
          userMsg.feedback = feedback;
          this._applyFeedback(userMsg, feedback);
          this._queueRender();
        })
        .catch(error => console.warn("Feedback unavailable:", error && (error.code || error.message)));
    }

    _applyFeedback(userMsg, feedback) {
      const corrections = Array.isArray(feedback.corrections) ? feedback.corrections : [];
      this.stats.turns += 1;
      if (corrections.length === 0) this.stats.clean += 1;
      else this.stats.corrected += 1;

      corrections.forEach(c => {
        this.mistakesIdentified.push({
          original: c.original,
          corrected: c.corrected,
          explanation: c.explanationEs,
          timestamp: Date.now()
        });
      });

      (feedback.usefulWords || []).forEach(w => {
        if (w && w.word && !this.vocabularyDiscovered.some(v => v.word.toLowerCase() === w.word.toLowerCase())) {
          this.vocabularyDiscovered.push({ word: w.word, meaningEs: w.meaningEs || "" });
        }
      });

      // Record real results (previously every message was logged as correct).
      try {
        if (this.app && this.app.adaptiveEngine && typeof this.app.adaptiveEngine.recordActivity === "function") {
          this.app.adaptiveEngine.recordActivity({
            skill: "speaking",
            topic: `Conversation - ${this.scenario}`,
            difficulty: this.level,
            isCorrect: corrections.length === 0,
            userAnswer: userMsg.content,
            correctAnswer: corrections.length ? corrections[0].corrected : userMsg.content
          });
        }
      } catch (error) {
        console.warn("Could not record speaking activity:", error && error.message);
      }
    }

    /* -------------------------------------------------------------- *
     * Voice input (Web Speech API) and session summary
     * -------------------------------------------------------------- */

    _mountControls() {
      if (document.getElementById("ai-chat-controls")) return;
      const anchor = document.getElementById("ai-chat-starters") || document.getElementById("ai-chat-thread");
      if (!anchor || !anchor.parentNode) return;

      const bar = el("div", "ai-chat-controls");
      bar.id = "ai-chat-controls";

      const SR = global.SpeechRecognition || global.webkitSpeechRecognition;
      if (SR) {
        const mic = el("button", "btn-chat-mic", "🎤 Hablar");
        mic.type = "button";
        mic.title = "Habla en inglés; se enviará al terminar de hablar";
        mic.onclick = () => this.toggleMic();
        this._micBtn = mic;
        bar.appendChild(mic);
      }

      const speakLabel = el("label", "chat-toggle");
      const speakCb = document.createElement("input");
      speakCb.type = "checkbox";
      speakCb.onchange = () => { this.autoSpeak = speakCb.checked; };
      speakLabel.appendChild(speakCb);
      speakLabel.appendChild(document.createTextNode(" Leer respuestas en voz alta"));
      bar.appendChild(speakLabel);

      const endBtn = el("button", "btn-chat-summary", "📋 Terminar y ver resumen");
      endBtn.type = "button";
      endBtn.onclick = () => this.endSession();
      bar.appendChild(endBtn);

      anchor.parentNode.insertBefore(bar, anchor.nextSibling);
    }

    toggleMic() {
      if (this.isListening) { this._stopMic(); return; }
      const SR = global.SpeechRecognition || global.webkitSpeechRecognition;
      const input = document.getElementById("ai-chat-input");
      if (!SR || !input || this.isLoading) return;

      if (global.speechSynthesis) global.speechSynthesis.cancel();
      const rec = new SR();
      rec.lang = "en-US";
      rec.interimResults = true;
      rec.continuous = false;

      let finalText = "";
      rec.onresult = event => {
        let interim = "";
        for (let i = event.resultIndex; i < event.results.length; i += 1) {
          const result = event.results[i];
          if (result.isFinal) finalText += result[0].transcript;
          else interim += result[0].transcript;
        }
        input.value = (finalText + interim).trim();
      };
      rec.onerror = event => {
        this._setMicState(false);
        if (event.error === "not-allowed" || event.error === "service-not-allowed") {
          this.history.push({
            role: "assistant", isNotice: true, timestamp: Date.now(),
            content: "🎤 No pude acceder al micrófono. Revisa el permiso del navegador para este sitio."
          });
          this.render();
        }
      };
      rec.onend = () => {
        this._setMicState(false);
        const text = finalText.trim();
        if (text && this.autoSend) {
          input.value = "";
          this.sendMessage(text);
        }
      };

      this.recognition = rec;
      try {
        rec.start();
        this._setMicState(true);
      } catch (error) {
        this._setMicState(false);
      }
    }

    _stopMic() {
      if (this.recognition) {
        try { this.recognition.stop(); } catch (error) { /* already stopped */ }
      }
      this._setMicState(false);
    }

    _setMicState(listening) {
      this.isListening = listening;
      if (this._micBtn) {
        this._micBtn.textContent = listening ? "⏹️ Escuchando… (toca para parar)" : "🎤 Hablar";
        this._micBtn.classList.toggle("is-listening", listening);
      }
    }

    endSession() {
      const meta = SCENARIOS_METADATA[this.scenario] || SCENARIOS_METADATA.free;
      const userTurns = this.history.filter(m => m.role === "user").length;
      let content;

      if (userTurns === 0) {
        content = "Todavía no hay conversación que resumir. Escribe o di algo en inglés primero.";
      } else {
        const lines = [`📋 Resumen · ${meta.name} · nivel ${this.level}`, `Mensajes tuyos: ${userTurns}`];
        if (this.stats.turns > 0) {
          lines.push(`Analizados: ${this.stats.turns} · sin errores: ${this.stats.clean} · con correcciones: ${this.stats.corrected}`);
        }
        if (this.mistakesIdentified.length) {
          lines.push("", "Para repasar:");
          this.mistakesIdentified.slice(0, 5).forEach(m => lines.push(`• "${m.original}" → "${m.corrected}"`));
        }
        if (this.vocabularyDiscovered.length) {
          lines.push("", "Palabras nuevas:");
          this.vocabularyDiscovered.slice(0, 6).forEach(v => lines.push(`• ${v.word}${v.meaningEs ? " — " + v.meaningEs : ""}`));
        }
        if (!this.mistakesIdentified.length && this.stats.turns > 0) lines.push("", "¡Buen trabajo! No encontré errores importantes.");
        content = lines.join("\n");
      }

      this.history.push({ role: "assistant", isNotice: true, content, timestamp: Date.now() });
      this.render();
    }

    /* -------------------------------------------------------------- *
     * Offline fallback (unchanged behaviour from v4.0)
     * -------------------------------------------------------------- */

    _generateRuleBasedReply(userText) {
      const lower = userText.toLowerCase();

      let correctionNote = "";
      if (lower.includes("i have ") && (lower.includes("years") || lower.includes("age"))) {
        correctionNote = "\n\n💡 Grammar Tip: In English, use 'I am ... years old' instead of 'I have ... years'.";
        this.mistakesIdentified.push({ original: "I have ... years", corrected: "I am ... years old", explanation: "Age expression" });
      } else if (lower.startsWith("i want ")) {
        correctionNote = "\n\n💡 Politeness Tip: In customer service or formal settings, 'I would like' or 'Could I have' sounds more natural and polite than 'I want'.";
      }

      if (this.scenario === "restaurant") {
        if (lower.includes("menu") || lower.includes("drink") || lower.includes("water") || lower.includes("beer")) {
          return `Certainly! Here is our menu. We have sparkling water, freshly squeezed orange juice, and iced tea. What would you like to start with?${correctionNote}`;
        } else if (lower.includes("order") || lower.includes("steak") || lower.includes("pasta") || lower.includes("salad") || lower.includes("fish")) {
          return `Excellent choice! How would you like that prepared, and would you care for any side dishes like roasted potatoes or a fresh garden salad?${correctionNote}`;
        } else if (lower.includes("bill") || lower.includes("check") || lower.includes("pay")) {
          return `Right away! I'll bring the check over. Did you enjoy your meal tonight? We accept both card and cash.${correctionNote}`;
        }
      } else if (this.scenario === "hotel") {
        if (lower.includes("reservation") || lower.includes("booking") || lower.includes("name")) {
          return `Thank you! I found your booking right here. You'll be staying in a deluxe suite on the fifth floor. May I see your ID, please?${correctionNote}`;
        } else if (lower.includes("breakfast") || lower.includes("wifi") || lower.includes("gym")) {
          return `Breakfast is served on the mezzanine floor from 6:30 AM to 10:00 AM. The high-speed WiFi network is 'HorizonGuest' with no password needed. Anything else I can assist with?${correctionNote}`;
        }
      } else if (this.scenario === "job") {
        return `Thank you for sharing that. It sounds like you have developed very valuable competencies. Could you describe a specific situation where you encountered a major challenge and how you resolved it?${correctionNote}`;
      } else if (this.scenario === "academic_debate") {
        return `That is a compelling argument. However, empirical studies often suggest that the efficacy of automated tools depends heavily on pedagogical framework and learner autonomy. How would you counter that point?${correctionNote}`;
      }

      return `That is very interesting! At CEFR ${this.level}, practicing clear sentence structures and varied vocabulary will help you communicate even more effectively. Could you elaborate a bit more on that?${correctionNote}`;
    }

    /* -------------------------------------------------------------- *
     * Rendering (DOM nodes + textContent only)
     * -------------------------------------------------------------- */

    _queueRender() {
      if (this._renderQueued) return;
      this._renderQueued = true;
      const schedule = global.requestAnimationFrame || (fn => setTimeout(fn, 16));
      schedule(() => {
        this._renderQueued = false;
        this.render();
      });
    }

    _renderFeedback(fb) {
      const corrections = Array.isArray(fb.corrections) ? fb.corrections : [];
      const note = el("div", "chat-feedback-note");

      if (corrections.length === 0 && !fb.naturalAlternative) {
        note.classList.add("is-ok");
        note.appendChild(el("div", "chat-feedback-line", "✅ Sonó natural."));
      }
      corrections.forEach(c => {
        const line = el("div", "chat-feedback-line");
        line.appendChild(document.createTextNode(`✏️ "${c.original}" → "${c.corrected}"`));
        if (c.explanationEs) line.appendChild(el("span", "chat-feedback-why", ` — ${c.explanationEs}`));
        note.appendChild(line);
      });
      if (fb.naturalAlternative) {
        note.appendChild(el("div", "chat-feedback-line", `💬 Más natural: "${fb.naturalAlternative}"`));
      }
      return note;
    }

    render() {
      const container = document.getElementById("ai-chat-thread");
      const scenarioSelect = document.getElementById("ai-chat-scenario-select");
      const levelSelect = document.getElementById("ai-chat-level-select");
      const statusIndicator = document.getElementById("ai-chat-status-indicator");
      const vocabList = document.getElementById("ai-chat-vocab-list");

      if (scenarioSelect && scenarioSelect.value !== this.scenario) scenarioSelect.value = this.scenario;
      if (levelSelect && levelSelect.value !== this.level) levelSelect.value = this.level;

      if (statusIndicator) {
        statusIndicator.textContent = "";
        const badge = el("span", `ai-status-pill ${this.isOnlineAI ? "online" : "local-mode"}`,
          this.isOnlineAI ? "⚡ IA en línea (OpenAI)" : "🛡️ Modo Práctica Guiada");
        statusIndicator.appendChild(badge);
      }

      if (vocabList) {
        vocabList.textContent = "";
        const itemTag = vocabList.tagName === "UL" || vocabList.tagName === "OL" ? "li" : "div";
        this.vocabularyDiscovered.forEach(v => {
          vocabList.appendChild(el(itemTag, "chat-vocab-item", v.meaningEs ? `${v.word} — ${v.meaningEs}` : v.word));
        });
      }

      if (!container) return;
      container.textContent = "";

      this.history.forEach(msg => {
        if (msg.streaming && !msg.content) return; // typing indicator covers this

        const row = el("div", `chat-bubble-row ${msg.role === "user" ? "user-row" : "bot-row"}`);
        const bubble = el(
          "div",
          `chat-bubble ${msg.role === "user" ? "chat-bubble-user" : "chat-bubble-bot"}${msg.isError ? " chat-bubble-error" : ""}${msg.isNotice ? " chat-bubble-notice" : ""}`
        );

        const header = el("div", "chat-bubble-header");
        header.appendChild(el("span", "chat-author-tag",
          msg.role === "user" ? ((this.app && this.app.state && this.app.state.username) || "Tú") : "Aura100 AI Tutor"));
        const d = new Date(msg.timestamp || Date.now());
        header.appendChild(el("span", "chat-time-tag",
          `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`));
        bubble.appendChild(header);

        bubble.appendChild(el("div", "chat-bubble-text", msg.content));

        if (msg.role === "assistant" && !msg.isError && !msg.isNotice && !msg.streaming
          && this.app && typeof this.app.speakText === "function") {
          const speakBtn = el("button", "btn-listen-bubble", "🔊 Escuchar");
          speakBtn.type = "button";
          speakBtn.title = "Escuchar pronunciación (SpeechSynthesis)";
          speakBtn.onclick = () => this.app.speakText(msg.content, 1.0);
          bubble.appendChild(speakBtn);
        }

        row.appendChild(bubble);
        if (msg.role === "user" && msg.feedback) row.appendChild(this._renderFeedback(msg.feedback));
        container.appendChild(row);
      });

      const last = this.history[this.history.length - 1];
      const waiting = this.isLoading && (!last || last.role === "user" || (last.streaming && !last.content));
      if (waiting) {
        const row = el("div", "chat-bubble-row bot-row");
        row.appendChild(el("div", "chat-bubble chat-bubble-bot chat-typing-indicator", "Escribiendo…"));
        container.appendChild(row);
      }

      container.scrollTop = container.scrollHeight;

      const suggestionsRow = document.getElementById("ai-chat-starters");
      if (suggestionsRow) {
        suggestionsRow.textContent = "";
        const meta = SCENARIOS_METADATA[this.scenario] || SCENARIOS_METADATA.free;
        (meta.suggestedStarters || []).forEach(starter => {
          const chip = el("button", "chat-starter-chip", starter);
          chip.type = "button";
          chip.onclick = () => {
            const input = document.getElementById("ai-chat-input");
            if (input) { input.value = starter; input.focus(); }
          };
          suggestionsRow.appendChild(chip);
        });
      }
    }
  }

  global.AIConversationPartner = AIConversationPartner;
  global.SCENARIOS_METADATA = SCENARIOS_METADATA;
})(window);
