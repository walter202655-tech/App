/*
 * Aura100 AI frontend client.
 * Safe to load in the browser: it contains no API key or private credential.
 * Include this file before script.js, then use window.Aura100AI.
 */
(function (global) {
  "use strict";

  class Aura100AIClient {
    constructor(options = {}) {
      this.basePath = options.basePath || "/api/ai";
      this.timeoutMs = options.timeoutMs || 60000;
    }

    _mapError(error, externalSignal) {
      if (error && error.name === "AbortError") {
        const abortError = new Error(
          externalSignal && externalSignal.aborted
            ? "Solicitud cancelada."
            : "La solicitud tardó demasiado. Inténtalo nuevamente."
        );
        abortError.code = externalSignal && externalSignal.aborted ? "REQUEST_ABORTED" : "REQUEST_TIMEOUT";
        return abortError;
      }
      if (error instanceof TypeError) {
        const networkError = new Error("No se pudo conectar con Aura100. Comprueba que el servidor esté funcionando.");
        networkError.code = "NETWORK_ERROR";
        return networkError;
      }
      return error;
    }

    async request(endpoint, payload) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

      try {
        const response = await fetch(`${this.basePath}${endpoint}`, {
          method: "POST",
          credentials: "same-origin",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
          signal: controller.signal
        });

        let data;
        try {
          data = await response.json();
        } catch {
          throw new Error("El servidor devolvió una respuesta no válida.");
        }

        if (!response.ok) {
          const error = new Error(data?.error || "No se pudo completar la solicitud.");
          error.status = response.status;
          error.code = data?.code || "REQUEST_FAILED";
          error.details = data?.details || null;
          throw error;
        }

        return data;
      } catch (error) {
        throw this._mapError(error);
      } finally {
        clearTimeout(timeout);
      }
    }

    async checkHealth() {
      try {
        const response = await fetch("/api/health", { credentials: "same-origin" });
        if (!response.ok) return { status: "error", aiConfigured: false, environment: "unknown" };
        return await response.json();
      } catch {
        return { status: "offline", aiConfigured: false, environment: "unknown" };
      }
    }

    async chat(payload) {
      const data = await this.request("/chat", payload);
      if (typeof data.reply !== "string") throw new Error("Respuesta de chat incompleta.");
      return data.reply;
    }

    /**
     * Streams a conversation turn. `onChunk(textSoFar)` is called as text arrives.
     * Resolves with the complete reply. Pass an AbortSignal to cancel.
     */
    async talkStream(payload, onChunk, externalSignal) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), this.timeoutMs);
      if (externalSignal) {
        if (externalSignal.aborted) controller.abort();
        else externalSignal.addEventListener("abort", () => controller.abort(), { once: true });
      }

      const splitMarker = raw => {
        const sep = raw.indexOf("\u0000");
        return sep >= 0
          ? { text: raw.slice(0, sep), marker: raw.slice(sep + 1) }
          : { text: raw, marker: "" };
      };

      try {
        const response = await fetch(`${this.basePath}/talk`, {
          method: "POST",
          credentials: "same-origin",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
          signal: controller.signal
        });

        if (!response.ok) {
          let data = null;
          try { data = await response.json(); } catch { /* non-JSON error body */ }
          const error = new Error(data?.error || "No se pudo completar la solicitud.");
          error.status = response.status;
          error.code = data?.code || "REQUEST_FAILED";
          throw error;
        }

        let raw = "";
        if (response.body && typeof response.body.getReader === "function") {
          const reader = response.body.getReader();
          const decoder = new TextDecoder();
          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            raw += decoder.decode(value, { stream: true });
            if (typeof onChunk === "function") onChunk(splitMarker(raw).text);
          }
          raw += decoder.decode();
        } else {
          raw = await response.text(); // browsers without streaming support
        }

        const { text, marker } = splitMarker(raw);
        if (marker === "BLOCKED") {
          const error = new Error("La respuesta generada no pudo mostrarse. Prueba con otra formulación.");
          error.code = "OUTPUT_BLOCKED";
          throw error;
        }
        if (marker === "ERROR" || !text.trim()) {
          const error = new Error("La conversación se interrumpió. Inténtalo nuevamente.");
          error.code = "STREAM_ERROR";
          throw error;
        }
        if (typeof onChunk === "function") onChunk(text.trim());
        return text.trim();
      } catch (error) {
        throw this._mapError(error, externalSignal);
      } finally {
        clearTimeout(timeout);
      }
    }

    async talkFeedback(payload) {
      const data = await this.request("/talk/feedback", payload);
      if (!data.feedback || typeof data.feedback !== "object") {
        throw new Error("Feedback incompleto.");
      }
      return data.feedback;
    }

    async evaluateWriting(payload) {
      const data = await this.request("/writing", payload);
      if (!data.evaluation || typeof data.evaluation !== "object") {
        throw new Error("Evaluación de escritura incompleta.");
      }
      return data.evaluation;
    }

    async explainTopic(payload) {
      const data = await this.request("/explain", payload);
      if (!data.explanation || typeof data.explanation !== "object") {
        throw new Error("Explicación incompleta.");
      }
      return data.explanation;
    }

    async generateExercises(payload) {
      const data = await this.request("/exercises", payload);
      if (!data.exerciseSet || !Array.isArray(data.exerciseSet.questions)) {
        throw new Error("El conjunto de ejercicios está incompleto.");
      }
      return data.exerciseSet;
    }

    async buildVocabularyEntry(payload) {
      const data = await this.request("/vocabulary", payload);
      if (!data.vocabulary || typeof data.vocabulary !== "object") {
        throw new Error("La entrada de vocabulario está incompleta.");
      }
      return data.vocabulary;
    }

    async createLearningPlan(payload) {
      const data = await this.request("/learning-plan", payload);
      if (!data.learningPlan || typeof data.learningPlan !== "object") {
        throw new Error("El plan de aprendizaje está incompleto.");
      }
      return data.learningPlan;
    }
  }

  global.Aura100AI = new Aura100AIClient();
})(window);
