# Integración (≈10 minutos)

Archivos (misma ruta relativa dentro de `Aura100/`):
- NUEVO   `src/conversation.mjs`
- NUEVO   `src/talk-routes.mjs`
- REEMPLAZA `src/ai-service.mjs`   (solo añade `streamText` y un parámetro `model` opcional)
- REEMPLAZA `ai-client.js`          (añade `talkStream` y `talkFeedback`; el resto igual)
- REEMPLAZA `js/ai-conversation.js`
- AÑADIR  `style-additions.css` al final de `style.css`

## server.mjs (2 líneas)
1. Arriba, junto a los demás imports:
   import { registerTalkRoutes } from "./src/talk-routes.mjs";
2. Justo después de la ruta `app.post("/api/ai/chat", ...)` y antes de `const blockedStaticPaths`:
   registerTalkRoutes(app);

## package.json → script "check"
Añade: `&& node --check src/conversation.mjs && node --check src/talk-routes.mjs`

## Variables de entorno (Railway)
- AI_RATE_LIMIT_MAX=120      (cada turno usa 2 peticiones; con 20 cada 10 min solo caben ~10 turnos)
- TRUST_PROXY=true           (si no, todos los usuarios comparten la misma IP del proxy y el mismo límite)
- Opcional: OPENAI_FEEDBACK_MODEL (modelo más barato/rápido para las correcciones)
- Opcional: OPENAI_TALK_MODEL

## Compatibilidad
- /api/ai/chat NO se toca: Academy Hub (tutor Cambridge, study coach) sigue igual.
- Los IDs del DOM son los mismos. Los controles nuevos (micrófono, leer en voz alta, resumen) se crean
  solos debajo de `#ai-chat-starters`.
