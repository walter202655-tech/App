import {
  turnRequestSchema,
  feedbackRequestSchema,
  talkInstructions,
  feedbackInstructions,
  FEEDBACK_SCHEMA
} from "./conversation.mjs";
import { streamText, generateStructured, moderateText } from "./ai-service.mjs";

// Markers appended after the reply text when something goes wrong mid-stream.
const MARK_BLOCKED = "\u0000BLOCKED";
const MARK_ERROR = "\u0000ERROR";

function rejectBadRequest(res, parsed) {
  return res.status(400).json({
    error: "Los datos enviados no son válidos.",
    code: "BAD_REQUEST",
    details: parsed.error.issues.map(issue => ({ path: issue.path.join("."), message: issue.message }))
  });
}

export function registerTalkRoutes(app) {
  /**
   * POST /api/ai/talk
   * Streams the partner's reply as plain text (chunked). The learner's message is
   * moderated before generation; the finished reply is moderated afterwards.
   */
  app.post("/api/ai/talk", async (req, res, next) => {
    const parsed = turnRequestSchema.safeParse(req.body);
    if (!parsed.success) return rejectBadRequest(res, parsed);
    const data = parsed.data;

    const controller = new AbortController();
    res.on("close", () => { if (!res.writableEnded) controller.abort(); });

    let started = false;
    try {
      if (await moderateText(data.message)) {
        return res.status(422).json({
          error: "No puedo procesar ese contenido. Reformula tu mensaje como una conversación segura.",
          code: "CONTENT_REVIEW_REQUIRED"
        });
      }

      res.status(200);
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      res.setHeader("X-Accel-Buffering", "no"); // keep proxies (Railway/nginx) from buffering
      res.flushHeaders();
      started = true;

      let reply = "";
      const deltas = streamText({
        instructions: talkInstructions(data.level, data.scenario),
        input: [...data.history, { role: "user", content: data.message }],
        maxOutputTokens: 600, // generous: reasoning models count thinking tokens here
        signal: controller.signal
      });
      for await (const delta of deltas) {
        reply += delta;
        res.write(delta);
      }

      if (!reply.trim()) res.write(MARK_ERROR);
      else if (await moderateText(reply)) res.write(MARK_BLOCKED);
      res.end();
    } catch (error) {
      if (controller.signal.aborted) return;
      if (!started) return next(error);
      console.error("Aura100 talk stream error:", error?.code || error?.name || "UnknownError");
      res.write(MARK_ERROR);
      res.end();
    }
  });

  /**
   * POST /api/ai/talk/feedback
   * Short structured review of the learner's last message. Called in parallel
   * with /talk so corrections never slow down or interrupt the conversation.
   */
  app.post("/api/ai/talk/feedback", async (req, res, next) => {
    try {
      const parsed = feedbackRequestSchema.safeParse(req.body);
      if (!parsed.success) return rejectBadRequest(res, parsed);
      const data = parsed.data;

      const result = await generateStructured({
        instructions: feedbackInstructions(data.level),
        input: JSON.stringify({ partnerMessage: data.partnerMessage, learnerMessage: data.message }),
        schemaName: "aura100_talk_feedback",
        schema: FEEDBACK_SCHEMA,
        maxOutputTokens: 700,
        model: process.env.OPENAI_FEEDBACK_MODEL || undefined
      });

      // Guard against invented errors: a correction is only kept if the "original"
      // text really appears in what the learner wrote.
      const lowerMessage = data.message.toLowerCase();
      const corrections = (Array.isArray(result.corrections) ? result.corrections : [])
        .filter(item =>
          item && item.original && item.corrected
          && item.original.trim().toLowerCase() !== item.corrected.trim().toLowerCase()
          && lowerMessage.includes(item.original.trim().toLowerCase())
        )
        .slice(0, 2);

      res.json({
        feedback: {
          isCorrect: corrections.length === 0,
          corrections,
          naturalAlternative: corrections.length === 0 ? String(result.naturalAlternative || "") : "",
          usefulWords: (Array.isArray(result.usefulWords) ? result.usefulWords : []).slice(0, 2)
        }
      });
    } catch (error) { next(error); }
  });
}
